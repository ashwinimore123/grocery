		<!-- Main Footer-->
		<style type="text/css">
			footer{
				position: relative;
				bottom: 0
			}
		</style>
		<footer>
			<div class="main-footer text-center">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<span>Copyright © 2023 <a href="#"></a>. Designed by <a href="https://www.spruko.com/"></a> All rights reserved.</span>
						</div>
					</div>
				</div>
			</div>
			</footer>
			<!--End Footer-->