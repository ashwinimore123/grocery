<?php $__env->startSection('content'); ?>
    <h1 class="mt-4 mb-4">Grocery Inventory Management</h1>

    <form action="/grocery/add_item" method="post">
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Item Name:</label>
            <input type="text" class="form-control" name="name" required>
        </div>

        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="number" class="form-control" name="quantity" required>
        </div>

        <button type="submit" class="btn btn-primary">Add Item</button>
    </form>

    <h2 class="mt-4">Inventory</h2>
    <ul class="list-group">
        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($item->name); ?> - Quantity: <?php echo e($item->quantity); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/grocery/index.blade.php ENDPATH**/ ?>